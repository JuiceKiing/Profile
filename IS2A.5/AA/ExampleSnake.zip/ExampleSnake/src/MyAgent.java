
import java.util.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {

    public static void main(String args[]) throws IOException {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);
            
            int grid[][] = new int[Integer.parseInt(temp[2])][Integer.parseInt(temp[1])];
        	for(int i =0;i<grid.length;++i){
        			for(int j =0;j<grid.length;++j){
        				grid[i][j]=0;
        			}
        		}
        	
            while (true) {
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }
                
                String apple = line;
                //do stuff with apple
                String[] aCoords = apple.split(" ");
                ArrayList<String[]>zombies = new ArrayList<String[]>();
                for (int i = 0; i < 3; ++i) {
                    String zombieLine = br.readLine();
                    drawSnake(zombieLine,grid);
                    //zombies.add();
                }
            
                ArrayList<String>enemies = new ArrayList<String>();
                ArrayList<String[]>aL = new ArrayList<String[]>();
                int move = 5;
                int mySnakeNum = Integer.parseInt(br.readLine());
                for(int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    drawSnake(snakeLine,grid);
                    if (i == mySnakeNum) {
                    	//hey! That's me :)
                    	int aplX = Integer.parseInt(aCoords[0]);
                        int aplY = Integer.parseInt(aCoords[1]);
                        grid[aplX][aplY] = 0;
                        
                        
                    	String[] sCoords = snakeLine.split(" ");
                    
                    		String[] sHead = sCoords[3].split(",");
                			String[] sNext = sCoords[4].split(",");
                			
                			int headX = Integer.parseInt(sHead[0]);
                			int headY = Integer.parseInt(sHead[1]);
                			int nextX = Integer.parseInt(sNext[0]);
                			int nextY = Integer.parseInt(sNext[1]);
            
                			Queue <int []> queue = new LinkedList <int []> ();
                			ArrayList<int[]>visited = new ArrayList<int[]>();
            				int [] start = {headX,headY};
            				queue.add(start);
            				grid[headY][headX]=1;
            				visited.add(start);
            				
            				while(queue.peek()!= null){
            					
            					int[] exp = queue.remove();
            					for(int[] r : visited){
            						if(r==exp){
            							//System.out.println("log Path Exists");
            							continue;
            						}
            					}
            					if(exp[0] == aplY && exp[1]== aplX){
            						for(int s =0;s<grid.length;++s){
            		        			for(int t =0;t<grid.length;++t){
            		        				grid[s][t]=0;
            		        			}
            		        		}
            					}
            					
            					if(aplY <= headY && headY > nextY){ // apple above and snake is moving down
                    				if(aplX<=headX){ // apple to left
                    					if(exp[1]+1<=49 && grid[exp[1]+1][exp[0]]==0){
                    						move = 2;
                    						grid[exp[1]+1][exp[0]]=5;
                    						int[] ta = {exp[1]+1,exp[0]};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}else{
                    					if(exp[1]+1<=49 && grid[exp[1]+1][exp[0]]==0){
                    						move = 3;
                    						grid[exp[1]+1][exp[0]]=5;
                    						int[] ta = {exp[1]+1,exp[0]};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}
            			    	}else if(aplY >= headY && headY < nextY){ // apple below and snake is moving up
                    				if(aplX<=headX){ // apple left of snake
                    					if(exp[1]-1 >=0 && grid[exp[1]-1][exp[0]]==0){
                    						move = 2;
                    						grid[exp[1]-1][exp[0]]=5;
                    						int[] ta = {exp[1]-1,exp[0]};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}else{
                    					if(exp[1]-1>=0 && grid[exp[1]-1][exp[0]]==0){
                    						move = 3;
                    						grid[exp[1]-1][exp[0]]=5;
                    						int[] ta = {exp[1]-1,exp[0]};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}
            					}else if(aplX <= headX && headX > nextX){ //apple left and snake is right
                    				if(aplY<=headY){ // apple above snake
                    					if(exp[0]+1<=49 && grid[exp[1]][exp[0]+1]==0){
                    						move = 0;
                    						grid[exp[1]][exp[0]+1]=5;
                    						int[] ta = {exp[1],exp[0]+1};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}else{
                    					if(exp[0]+1<=49 && grid[exp[1]][exp[0]+1]==0){
                    						move = 1;
                    						grid[exp[1]][exp[0]+1]=5;
                    						int[] ta = {exp[1],exp[0]+1};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}
            					}else if (aplX >= headX && headX < nextX){ //apple right and snake is left
                    				if(aplY <= headY){ //apple above snake
                    					if(exp[0]-1>=0 && grid[exp[1]][exp[0]-1]==0){
                    						move = 0;
                    						grid[exp[1]][exp[0]-1]=5;
                    						int[] ta = {exp[1],exp[0]-1};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}else{
                    					if(exp[0]-1>=0 && grid[exp[1]][exp[0]-1]==0){
                    						move = 1;
                    						grid[exp[1]][exp[0]-1]=5;
                    						int[] ta = {exp[1],exp[0]-1};
                    						queue.add(ta);
                    						visited.add(ta);
                    					}
                    				}
                    			}
            					
            				}
                }
             // finished reading, calculate move:
                System.out.println("log calculating...");
    			System.out.println(move);
    			printBoard(grid);
                }
                

            } 
            
        }catch (IOException e) {
            e.printStackTrace();
        }
       
    }
    public String[] getHead(String snakeLine){
    	String[] snakeArr = snakeLine.split(" ");
        return snakeArr[0].split(",");
        
    }
    public String[] getBody(String snakeLine){
    	String[] snakeArr = snakeLine.split(" ");
        return snakeArr[1].split(",");
    }
    public String[] getEHead(String snakeLine){
    	String[] snakeArr = snakeLine.split(" ");
        return snakeArr[3].split(",");
        
    }
    
    public String[] getEBody(String snakeLine){
    	String[] snakeArr = snakeLine.split(" ");
        return snakeArr[4].split(",");
    }
    public static void drawSnake(String sDesc,int[][] grid){
    	
		String[] pairs =  sDesc.split(" ");
		
		for(int i = 4; i<pairs.length;++i){
			drawLine(pairs[i-1],pairs[i],grid);
		}
	}
   
    public static void drawLine(String p1,String p2,int[][] pArea){


		String[] point1 = p1.split(",");
		String x1 = point1[0];
		String y1 = point1[1];

		String[] point2 = p2.split(",");
		String x2 = point2[0];
		String y2 = point2[1];

		int intX1 = Integer.parseInt(x1); 
		int intY1 = Integer.parseInt(y1);
		int intX2 = Integer.parseInt(x2); 
		int intY2 = Integer.parseInt(y2);
		int minX,maxX,minY,maxY;

		if(intX1>intX2){
			minX = intX2;
			maxX = intX1;
		}else{
			minX = intX1;
			maxX = intX2;
		}
		if(intY1>intY2){
			minY = intY2;
			maxY = intY1;
		}else{
			minY = intY1;
			maxY = intY2;
		}
		if(intX1 == intX2){
			for(int i = minY;i<maxY+1;++i){
				pArea[i][intX1]=1;
			}
		
		}
		if(intY1 == intY2){
			for(int j = minX;j<maxX+1;++j){

				pArea[intY1][j]=1;
			}	

		}
		
	}
    public static void printBoard(int[][] grid){
		for(int i = 0; i<grid.length;++i){
			for(int j = 1; j<grid.length;++j){
				System.err.print(grid[i][j-1]+" ");
				if(j == grid.length-1){
					System.err.print(grid[i][j]);

				}

			}
			System.err.println();
		}
	}
}