﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;


namespace FundMe
{
    public partial class UpdateApplicant : Form
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\rakza\Desktop\MonetaV1\Proj Latest\project\FundMe\DBSMoneta New.accdb");
        string strStudentUni;
        string intStudentNum;
        string applicant_ID="";
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DBSMoneta;User Id=""; Password=myPassword"";.";
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;

        public UpdateApplicant()
        {
            InitializeComponent();
        }

        // Validate Input
        private bool ValidateData(bool blnValid)
        {
            //Institution
            if (textBox14.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Institution!", "error");
            //Applicant stud number
            if (textBox13.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student Number", "error");
            //first name
            if (textBox5.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter First Name", "error");
            //last name
            if (textBox4.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Last Name", "error");
            //ID
            if (textBox3.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter ID Number", "error");
            //DOB
            if (textBox2.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Date of Birth", "error");
            //Cell Number
            if (textBox6.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Cell Number", "error");
            //Email
            if (textBox7.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Email Address", "error");
            //Home/Postal 
            if (textBox8.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Home/Postal address", "error");
            //University
            if (textBox10.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student University", "error");
            //Degree Name
            if (textBox9.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Degree Name", "error");
            //Stud Number
            if (textBox12.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student Number", "error");
            //Status
            if (textBox11.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter status", "error");
            return blnValid;

        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {



            strStudentUni = textBox14.Text;
            intStudentNum = (textBox13.Text);

            conn.Open();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter("select applicant_firstName, applicant_lastName,applicant_IDno from tblApplicant where applicant_studentNo ='" + intStudentNum + "'", conn);


            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();





        }

            private void button9_Click(object sender, EventArgs e)
            {
                // return to main page
                Form1 temp = new Form1();
                temp.Region = this.Region;
                temp.Show();
                this.Hide();
            
            }

        private void button2_Click(object sender, EventArgs e)
        {
            intStudentNum = textBox13.Text;

            conn.Open();
            OleDbCommand cmd2 = new OleDbCommand("select applicant_IDNo from tblApplicant where applicant_studentNo=@1", conn);
            cmd2.Parameters.AddWithValue("@1", intStudentNum);

            OleDbDataReader appstatusrdr = cmd2.ExecuteReader();



            

            while (appstatusrdr.Read())
            {
                applicant_ID = appstatusrdr["applicant_IDNo"].ToString();
            }

            conn.Close();



            conn.Open();
            OleDbCommand cmd = new OleDbCommand("update tblApplicant set applicant_status = @1 where applicant_IDNo = @2", conn);
            cmd.Parameters.AddWithValue("@1",true);
            cmd.Parameters.AddWithValue("@2",applicant_ID);
            cmd.ExecuteNonQuery();
            conn.Close();

            label25.Visible = true;


        }
    }
    }

