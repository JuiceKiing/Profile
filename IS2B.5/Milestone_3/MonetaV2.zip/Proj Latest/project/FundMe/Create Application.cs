﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using System.Data.OleDb;

namespace FundMe
{


    public partial class Create_Application : Form
    {

        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\rakza\Desktop\MonetaV1\Proj Latest\project\FundMe\DBSMoneta New.accdb");

        string appIDno;
        string adminID = "1111110";
        string FundType = "";
        double rAmount;
        



        public Create_Application()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {

            bool blnValidID = true;
            appIDno = textBox1.Text;

         


            if (appIDno.Length != 13) {
                blnValidID = false;

            }

            if (appIDno.Length == 13)
            {

                for (int i = 0; i < 13; i++)
                {
                    blnValidID = char.IsNumber(appIDno[i]);

                }
            }

            
            conn.Open();
            //OleDbDataAdapter da = new OleDbDataAdapter("select applicant_status from tblApplicant where applicant_IDNo=appIDNo", conn);
            OleDbCommand cmd = new OleDbCommand("select applicant_status from tblApplicant where applicant_IDNo=@1", conn);
            cmd.Parameters.AddWithValue("@1",appIDno);

            OleDbDataReader appstatusrdr = cmd.ExecuteReader();



            string appStatus="";
            
            while (appstatusrdr.Read())
            {
              appStatus = appstatusrdr["applicant_status"].ToString();
             }

            conn.Close();
           

            if (blnValidID == false )
            {
                MessageBox.Show("Enter a valid ID number", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {

                if (appStatus == "False" || appStatus=="")
                {

                    MessageBox.Show("The applicant is not eligible for application", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {









                    radioButton1.Enabled = true;
                    radioButton2.Enabled = true;
                    radioButton3.Enabled = true;
                    radioButton4.Enabled = true;
                    radioButton5.Enabled = true;
                    radioButton6.Enabled = true;

                    button2.Enabled = true;
                    

                }


            }

           

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            
           
           
            foreach (RadioButton r in groupBox1.Controls)
            {
                if (r.Checked)
                    FundType = r.Text;
            }

            if (FundType == "")
            {
                MessageBox.Show("Please select the application fund type", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            } else
            {

                textBox2.Enabled = true;
                button3.Enabled = true;
                

                


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            
            bool isCurr = double.TryParse(textBox2.Text, out double n);

            if (isCurr == false)
            {

            }
            else
            {
                rAmount = Convert.ToDouble(textBox2.Text);

                conn.Close();
                conn.Open();
               // OleDbCommand cmd = new OleDbCommand("insert into tblApplication (application_ID,applicant_IDNo,admin_ID,donation_ID,application_fundType,application_requiredAmount,application_date,application_status,application_fundedAmount) values (@1,@2,@3,@4,@5,@6,@7,@8,@9,)", conn);
                  OleDbCommand cmd = new OleDbCommand("insert into tblApplication (application_ID,applicant_IDNo,admin_ID,donation_ID,application_fundType,application_requiredAmount,application_date,application_status,application_fundedAmount) values (@1,@2,@3,@4,@5,@6,@7,@8,@9)", conn);
                cmd.Parameters.AddWithValue("@1",2254451145);
               
               cmd.Parameters.AddWithValue("@2", appIDno);
                cmd.Parameters.AddWithValue("@3", adminID);
               cmd.Parameters.AddWithValue("@4", "");
                cmd.Parameters.AddWithValue("@5", FundType);
                cmd.Parameters.AddWithValue("@6", rAmount);
                cmd.Parameters.AddWithValue("@7", (DateTime.Today).ToString("dd-MM-yy"));
                cmd.Parameters.AddWithValue("@8", "unfunded");
                cmd.Parameters.AddWithValue("@9", 0);

                cmd.ExecuteNonQuery();

                conn.Close();


                label2.Visible = true;
                label2.Text = "APPLICATION SUUCESSFULLY CREATED.";



               

            }

        }

        private void Create_Application_Load(object sender, EventArgs e)
        {
            label2.Visible = false;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.Region = this.Region;
            temp.Show();
            this.Hide();
        }
    }
}
