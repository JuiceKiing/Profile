﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace FundMe
{
    public partial class Create_Donation : Form
    {
        string strStudentUni;
        string FundType;
        long intStudentNum;
        string intApplicantID;
        int iloop;
        string sFund="";
        string donorcell;
        string adminID = "1111110";
        string appID="";
        string donorID="";
        string Transfer;
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\rakza\Desktop\MonetaV1\Proj Latest\project\FundMe\DBSMoneta New.accdb");

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Vendor;Integrated Security=True";
        //Is this where i link the data base?
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;


        public Create_Donation()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            intStudentNum = Convert.ToInt64(textBox5.Text);

            //first assign the applicant ID number



            conn.Open();
            //OleDbDataAdapter da = new OleDbDataAdapter("select applicant_status from tblApplicant where applicant_IDNo=appIDNo", conn);
            OleDbCommand cmd = new OleDbCommand("select applicant_IDNo from tblApplicant where applicant_studentNo=@1", conn);
            cmd.Parameters.AddWithValue("@1", intStudentNum);

            OleDbDataReader appstatusrdr = cmd.ExecuteReader();



            string appID = "";

            while (appstatusrdr.Read())
            {
                appID = appstatusrdr["applicant_IDNo"].ToString();
            }

            conn.Close();
       
            Transfer = appID;


            //clear the data grid
            //dataGridView1.Rows.Clear();
            //dataGridView1.Columns.Clear();




            //repopulate the data grid with the applicatins

            string Status = "Partially Funded";

            conn.Open();
            DataTable dt = new DataTable();
            
            OleDbDataAdapter da = new OleDbDataAdapter("select application_ID, application_fundType, application_requiredAmount, application_fundedAmount, application_status from tblApplication where applicant_IDNo ='" + appID + "'and  application_status='"+Status+"'", conn);
         
            
            

            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();

            //assign fund types


            conn.Open();
            OleDbCommand cmd2 = new OleDbCommand("select application_fundType from tblApplication where applicant_IDNo=@1", conn);
            cmd2.Parameters.AddWithValue("@1", appID);

            OleDbDataReader statusrdr = cmd2.ExecuteReader();

            
            while (statusrdr.Read())
            {
               FundType =statusrdr["application_fundType"].ToString();

                if (FundType == "Historical Debt Relief")
                {
                    radioButton1.Enabled = true;
                }

                if (FundType == "Accommodation")
                {
                    radioButton11.Enabled = true;
                }

                if (FundType == "Tuition")
                {
                    radioButton10.Enabled = true;
                }

                if (FundType == "Study Materials")
                {
                    radioButton9.Enabled = true;
                }

                if (FundType == "Telecommunications")
                {
                    radioButton8.Enabled = true;
                }

                if (FundType == "Living Expenses")
                {
                    radioButton7.Enabled = true;
                }


            }

            conn.Close();


           

        }

        private void Create_Donation_Load(object sender, EventArgs e)
        {
            label11.Visible = false;
            radioButton1.Enabled = false;
            radioButton11.Enabled = false;
            radioButton10.Enabled = false;
            radioButton9.Enabled = false;
            radioButton8.Enabled = false;
            radioButton7.Enabled = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {

            bool blnValidDonor=false;


            conn.Open();
            OleDbCommand cmd2 = new OleDbCommand("select donor_cell from tblDonor ", conn);
        

            OleDbDataReader statusrdr = cmd2.ExecuteReader();


            while (statusrdr.Read())
            {
                donorcell = statusrdr["donor_cell"].ToString();

               if (donorcell == textBox1.Text)
                {
                    blnValidDonor = true;


                }


            }

            conn.Close();


             if (textBox1.Text.Length != 10)
            {
                MessageBox.Show("Please enter valid cell", "Error",
             MessageBoxButtons.OK, MessageBoxIcon.Error);

            } else
            {
                if (blnValidDonor == true)
                {

                    //get application Id

                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand("select application_ID from tblApplication where applicant_IDNo =@1", conn);
                    cmd.Parameters.AddWithValue("@1", Transfer);
                    OleDbDataReader appstatusrdr = cmd.ExecuteReader();
                   // appID = "";

                    while (appstatusrdr.Read())
                    {
                        appID = appstatusrdr["application_ID"].ToString();
                    }

                    conn.Close();

                    //get donor Id
                    conn.Open();
                    OleDbCommand cmd4 = new OleDbCommand("select donor_ID from tblDonor where donor_cell =@1", conn);
                    cmd4.Parameters.AddWithValue("@1", textBox1.Text);
                    OleDbDataReader appstatusrdrs = cmd4.ExecuteReader();
                    

                    while (appstatusrdrs.Read())
                    {
                        donorID = appstatusrdrs["donor_ID"].ToString();
                    }

                    conn.Close();






                    conn.Open();
                    // O
                    OleDbCommand cmd3 = new OleDbCommand("insert into tblDonation (donation_ID,application_ID,donor_ID,admin_ID,donation_fundedAmount,donation_date) values (@1,@2,@3,@4,@5,@6)", conn);
                    cmd3.Parameters.AddWithValue("@1",199999);

                    cmd3.Parameters.AddWithValue("@2",appID);
                    cmd3.Parameters.AddWithValue("@3", donorID);
                    cmd3.Parameters.AddWithValue("@4", adminID);
                    cmd3.Parameters.AddWithValue("@5", Convert.ToDouble(textBox4.Text));
                    cmd3.Parameters.AddWithValue("@6", (DateTime.Today).ToString("dd-MM-yy"));
                    

                    cmd3.ExecuteNonQuery();

                    conn.Close();





                }
                else { }

            }


            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (RadioButton r in groupBox1.Controls)
            {
                if (r.Checked)
                    sFund = r.Text;
            }

            if (sFund == "")
            {
                MessageBox.Show("Please select the application fund type", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            }else
            {
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.Region = this.Region;
            temp.Show();
            this.Hide();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            strStudentUni = textBox6.Text;
            intStudentNum = Convert.ToInt64(textBox5.Text);

            //Copied from Solution design doc i just changed the SQL statement 
            //this should display the applicants data from here how will we get the applications data

            conn.Open();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter("select applicant_firstName, applicant_lastName,applicant_IDno from tblApplicant where applicant_studentNo ='" + intStudentNum + "'", conn);
           
            
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();


           // using (SqlConnection con = new SqlConnection(connectionString))
            //{
              //  con.Open();
                //adpt = new SqlDataAdapter("select ApplicantFirstName, ApplicantLastName, Apllicant_IDno FROM tblApplicant WHERE (applicant_university =@1 ,applicant_studentNo=@2) );
                //dt = new DataTable();
                //adpt.Fill(dt);
                //dataGridView1.DataSource = dt;
           // }

        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
