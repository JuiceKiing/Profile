﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FundMe
{
    public partial class Create_Donation : Form
    {
        string strStudentUni;
        string FundType;
        int intStudentNum;
        int intApplicantID;
        int iloop;

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=Vendor;Integrated Security=True";
        //Is this where i link the data base?
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;


        public Create_Donation()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            //first assign the applicant ID number
            intApplicantID = 0;

            //clear the data grid
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            //repopulate the data grid with the applicatins
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
              //  adpt = new SqlDataAdapter("select Applicantion_ID, Applicantion_fundType, Application_RequiredAmount, application_fundedAmount, Application_Status FROM Applicantion WHERE ('" + intApplicationID + "') = Applicant_ID AND Application_Status IS NOT Funded", con);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
            }

            //assign fund types

            iloop = dataGridView1.RowCount;

            for (int i = 1; i <= iloop; i++)
            {
                //assign the fund type variable
                FundType = "null";

                if (FundType == "Historical Debt Relief")
                {
                    radioButton1.Enabled = true;
                }

                if (FundType == "Accommodation")
                {
                    radioButton11.Enabled = true;
                }

                if (FundType == "Tuition")
                {
                    radioButton10.Enabled = true;
                }

                if (FundType == "Study Materials")
                {
                    radioButton9.Enabled = true;
                }

                if (FundType == "Telecommunications")
                {
                    radioButton8.Enabled = true;
                }

                if (FundType == "Living Expenses")
                {
                    radioButton7.Enabled = true;
                }

            }


        }

        private void Create_Donation_Load(object sender, EventArgs e)
        {
            label11.Visible = false;
            radioButton1.Enabled = false;
            radioButton11.Enabled = false;
            radioButton10.Enabled = false;
            radioButton9.Enabled = false;
            radioButton8.Enabled = false;
            radioButton7.Enabled = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.Region = this.Region;
            temp.Show();
            this.Hide();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            strStudentUni = textBox6.Text;
            intStudentNum = Convert.ToInt32(textBox5.Text);

            //Copied from Solution design doc i just changed the SQL statement 
            //this should display the applicants data from here how will we get the applications data
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                adpt = new SqlDataAdapter("select ApplicantFirstName, ApplicantLastName, Apllicant_IDno FROM Applicant WHERE ('" + strStudentUni + "') = ApplicantUniversity AND ('" + intStudentNum + "') = ApplicantStudentNo ", con);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
            }

        }
    }
}
