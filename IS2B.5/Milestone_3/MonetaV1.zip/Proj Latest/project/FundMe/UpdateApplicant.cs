﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FundMe
{
    public partial class UpdateApplicant : Form
    {

        string strStudentUni;
        int intStudentNum;
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DBSMoneta;User Id=""; Password=myPassword"";.";
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;

        public UpdateApplicant()
        {
            InitializeComponent();
        }

        // Validate Input
        private bool ValidateData(bool blnValid)
        {
            //Institution
            if (textBox14.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Institution!", "error");
            //Applicant stud number
            if (textBox13.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student Number", "error");
            //first name
            if (textBox5.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter First Name", "error");
            //last name
            if (textBox4.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Last Name", "error");
            //ID
            if (textBox3.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter ID Number", "error");
            //DOB
            if (textBox2.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Date of Birth", "error");
            //Cell Number
            if (textBox6.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Cell Number", "error");
            //Email
            if (textBox7.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Email Address", "error");
            //Home/Postal 
            if (textBox8.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Home/Postal address", "error");
            //University
            if (textBox10.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student University", "error");
            //Degree Name
            if (textBox9.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Degree Name", "error");
            //Stud Number
            if (textBox12.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter Student Number", "error");
            //Status
            if (textBox11.Text == "")
                blnValid = false;
            MessageBox.Show("Please enter status", "error");
            return blnValid;

        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            strStudentUni = textBox14.Text;
            intStudentNum = Convert.ToInt32(textBox13.Text);

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                adpt = new SqlDataAdapter("SELECT * FROM Applicant WHERE Applicant_university = ('" + strStudentUni + "') AND Applicant_studentNo = ('" + intStudentNum + "') ", con);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;

            }
        }

            private void button9_Click(object sender, EventArgs e)
            {
                // return to main page
                Form1 temp = new Form1();
                temp.Region = this.Region;
                temp.Show();
                this.Hide();
            
            }
        }
    }

