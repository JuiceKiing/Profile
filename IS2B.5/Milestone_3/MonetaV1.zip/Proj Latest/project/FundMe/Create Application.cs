﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FundMe
{


    public partial class Create_Application : Form
    {

        string appIDno;
        string adminID = "1111110";
        string FundType = "";
        double rAmount;
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DBSMoneta;Integrated Security=True";
        //string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=DBSMoneta;User Id='Admin'; Password='';.";
        SqlCommand cmd;
        SqlDataAdapter adpt;
        DataTable dt;



        public Create_Application()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {

            bool blnValidID = true;
            appIDno = textBox1.Text;

         


            if (appIDno.Length != 13) {
                blnValidID = false;

            }

            if (appIDno.Length == 13)
            {

                for (int i = 0; i < 13; i++)
                {
                    blnValidID = char.IsNumber(appIDno[i]);

                }
            }


        
           
            if (blnValidID == false)
            {

                MessageBox.Show("Enter a valid ID number", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {

               




             


                    radioButton1.Enabled = true;
                    radioButton2.Enabled = true;
                    radioButton3.Enabled = true;
                    radioButton4.Enabled = true;
                    radioButton5.Enabled = true;
                    radioButton6.Enabled = true;

                    button2.Enabled = true;
                 
            }

            
              

           

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            
           
           
            foreach (RadioButton r in groupBox1.Controls)
            {
                if (r.Checked)
                    FundType = r.Text;
            }

            if (FundType == "")
            {
                MessageBox.Show("Please select the application fund type", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            } else
            {

                textBox2.Enabled = true;
                button3.Enabled = true;
                

                


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            
            bool isCurr = double.TryParse(textBox2.Text, out double n);

            if (isCurr == false)
            {

            }
            else
            {
                rAmount = Convert.ToDouble(textBox2.Text);

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    cmd = new SqlCommand("Insert into tblApplication values(('" + appIDno + "','" + adminID + "','" + "" + "','" + FundType + "','" + rAmount + "','" + DateTime.Today + "','" + "unfunded" + "','" + 0 + "')", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Created");

                    con.Close();

                }

            }

        }
    }
}
